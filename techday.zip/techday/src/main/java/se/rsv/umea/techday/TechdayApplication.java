package se.rsv.umea.techday;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechdayApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechdayApplication.class, args);
	}
}
